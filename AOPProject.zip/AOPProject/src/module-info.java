/**
 * 
 */
/**
 * @author burakkocabas
 *
 */
module AOPProject {
	requires java.desktop;
	requires java.sql;
}